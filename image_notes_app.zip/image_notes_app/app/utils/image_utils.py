import base64
from fastapi import UploadFile

def encode_image(uploaded_file: UploadFile) -> str:
    image_bytes = uploaded_file.file.read()
    return base64.b64encode(image_bytes).decode("utf-8")
