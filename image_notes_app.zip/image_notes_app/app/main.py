from fastapi import FastAPI
from app.routes import note_routes

from app.routes.note_routes import router as note_router

app = FastAPI(title="Image Note Processor")

# Register routes
app.include_router(note_routes.router)
# or
app.include_router(note_router)


@app.get("/")
def root():
    return {"message": "Welcome to the Image Notes API!"}
