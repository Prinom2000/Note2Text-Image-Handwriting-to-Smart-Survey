violence_keywords = {"kill", "gun", "attack", "murder", "fight", "bomb", "weapon", "war", "blood", "terror"}

def check_violence(text: str) -> str:
    words = set(text.lower().split())
    found = words.intersection(violence_keywords)
    if found:
        return f"Violent words found: {', '.join(found)}"
    return "100% clean text"
