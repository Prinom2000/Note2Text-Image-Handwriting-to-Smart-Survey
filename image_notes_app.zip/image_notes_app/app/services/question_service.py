from openai import OpenAI

client = OpenAI(api_key="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")

def generate_questions(text: str, max_q=5) -> str:
    prompt = f"Generate {max_q} simple and unique survey questions based on this note:\n{text}"
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        max_tokens=300,
        temperature=0.7,
    )
    return response.choices[0].message.content.strip()
