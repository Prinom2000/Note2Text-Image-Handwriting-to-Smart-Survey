from openai import OpenAI

client = OpenAI(api_key="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")

def extract_text_from_image(base64_image: str) -> str:
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "Extract all readable text from this note image."},
                    {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{base64_image}"}}
                ],
            }
        ],
    )
    return response.choices[0].message.content.strip()
