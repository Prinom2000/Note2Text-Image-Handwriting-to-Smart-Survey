from openai import OpenAI

client = OpenAI(api_key="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")

def suggest_related_notes(text: str) -> str:
    prompt = f"Suggest 2 related note titles based on the following note:\n{text}"
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
    )
    return response.choices[0].message.content.strip()
