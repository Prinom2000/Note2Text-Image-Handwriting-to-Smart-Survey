from openai import OpenAI

client = OpenAI(api_key="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")

def categorize_text(text: str) -> str:
    prompt = f"Categorize the following note into one word (Education, Health, Finance, Personal, Work, Other):\n{text}"
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
    )
    return response.choices[0].message.content.strip()
