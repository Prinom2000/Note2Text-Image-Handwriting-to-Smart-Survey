from fastapi import APIRouter, UploadFile, File
from fastapi.responses import JSONResponse

from app.utils.image_utils import encode_image
from app.services.ocr_service import extract_text_from_image
from app.services.question_service import generate_questions
from app.services.category_service import categorize_text
from app.services.related_service import suggest_related_notes
from app.services.violence_service import check_violence

router = APIRouter(prefix="/notes", tags=["Notes"])

@router.post("/process")
async def process_note(file: UploadFile = File(...)):
    try:
        # Step 1: Convert image to base64
        base64_image = encode_image(file)

        # Step 2: Extract text
        extracted_text = extract_text_from_image(base64_image)

        # Step 3: Generate questions
        questions = generate_questions(extracted_text)

        # Step 4: Categorize
        category = categorize_text(extracted_text)

        # Step 5: Related notes
        related_notes = suggest_related_notes(extracted_text)

        # Step 6: Violence detection
        violence_check = check_violence(extracted_text)

        return JSONResponse(content={
            "extracted_text": extracted_text,
            "generated_questions": questions,
            "category": category,
            "related_notes": related_notes,
            "violence_check": violence_check
        })

    except Exception as e:
        return JSONResponse(content={"error": str(e)}, status_code=500)